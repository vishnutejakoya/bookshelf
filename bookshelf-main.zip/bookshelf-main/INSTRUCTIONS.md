# Bookshelf Instructions

## 📝 Your Notes

Elaborate on your learnings here in `INSTRUCTIONS.md`

## Background

Each exercise will have some background information to help orient you around
the new concepts we'll be learning.

## Exercise

Here's where the exercise description will go. 👨‍💼 Peter will be giving you
project requirements here.

### Files

A list of the files you need to open to complete the exercise will be here. For
each file, there will be another file next to it with the suffix `.final` which
you can use as a reference if you get totally stuck.

## Extra Credit

### 💯 Example

Some of the exercises will come with extra credit you can do.

## 🦉 Elaboration and Feedback

After the instruction, if you want to remember what you've just learned, then
fill out the elaboration and feedback form:

https://ws.kcd.im/?ws=Build%20React%20Apps&e=&em=
